package br.com.cesarschool.poo.geral;

public enum Operacoes {
	CREDITAR, DEBITAR
}
