package br.com.cesarschool.poo.geral;

public enum Escore {
	INDISPONIVEL, BRONZE, PRATA, OURO, DIAMANTE
}
