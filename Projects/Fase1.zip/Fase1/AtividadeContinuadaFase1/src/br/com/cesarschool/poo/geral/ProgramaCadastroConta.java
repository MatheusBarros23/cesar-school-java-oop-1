package br.com.cesarschool.poo.geral;

public class ProgramaCadastroConta {
	public static void main(String[] args) {
		TelaConta tela = new TelaConta();
		tela.executarTela();
	}
}