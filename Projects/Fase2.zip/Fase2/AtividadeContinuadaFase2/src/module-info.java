/**
 * 
 */
/**
 * @author mathe
 *
 */
module fase1Att {
}