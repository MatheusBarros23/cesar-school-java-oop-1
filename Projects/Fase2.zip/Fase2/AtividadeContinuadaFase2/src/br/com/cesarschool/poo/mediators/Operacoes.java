package br.com.cesarschool.poo.mediators;

public enum Operacoes {
	CREDITAR, DEBITAR
}
