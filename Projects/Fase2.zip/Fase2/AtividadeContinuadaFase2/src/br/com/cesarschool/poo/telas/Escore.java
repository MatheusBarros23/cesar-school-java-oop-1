package br.com.cesarschool.poo.telas;

public enum Escore {
	INDISPONIVEL, BRONZE, PRATA, OURO, DIAMANTE
}
